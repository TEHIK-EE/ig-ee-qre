# ee.fhir.qre#1.0.0: Küsimustike teenus

## Pages

* [Sissejuhatus](index.md)
* [Allalaadimised](download.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Sagedus ajas](CodeSystem-sagedus-ajas.md)

### ValueSets

* [Sagedus ajas loend](ValueSet-sagedus-ajas.md)

### Resource Profiles

* [EEHealthDeclarationQuestionnaire](StructureDefinition-ee-health-declaration-questionnaire.md)
* [PETQuestionnaire](StructureDefinition-pet-questionnaire.md)

### ImplementationGuides

* [Küsimustike teenus](index.md)

### Questionnaires

* [Tervisedeklaratsioon](Questionnaire-Questionnaire-health-declaration.md)

### Examples

* [Patsiendi elulõpu tahteavaldus (Questionnaire)](Questionnaire-Questionnaire-PET.md)
* [Tervisedeklaratsioon CDA-st (Questionnaire)](Questionnaire-Questionnaire-health-declaration-cda.md)
* [Tervisedeklaratsioon (Questionnaire)](Questionnaire-Questionnaire-health-declaration.md)
