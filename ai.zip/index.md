# Sissejuhatus - Küsimustike teenus v1.0.0

* [**Table of Contents**](toc.md)
* **Sissejuhatus**

## Sissejuhatus

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ee/qre/ImplementationGuide/ee.fhir.qre | *Version*:1.0.0 |
| Active as of 2026-02-13 | *Computable Name*:QRE |

### Sissejuhatus

QRE (Questionnaire) ehk Küsimustike teenus on keskne rakendus, mille kaudu väljastatakse, säilitatakse ja hallatakse erinevate kasutusalade küsimustikke.

### Arendusvahendid ja lähtekood

QRE juurutusjuhendi lähtekood on leitav [GitHubis](https://github.com/TEHIK-EE/ig-ee-qre). Antud sait on välja töötatud [FHIR Shorthand](https://build.fhir.org/ig/HL7/fhir-shorthand) abiga. Täiendava informatsiooni FHIR Shorthand kohta saab leida [Confluence-is](https://confluence.hl7.org/display/FHIRI/FHIR+Shorthand), [GitHub-is](https://github.com/HL7/fhir-shorthand) ja [Zulip](https://chat.fhir.org) kanalis: #shorthand.

### IG metadata

This publication includes IP covered under the following statements.

* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* SNOMED Clinical Terms&reg; (SNOMED CT&reg;): [HDECL](Questionnaire-Questionnaire-health-declaration-with-text.md)




*There are no Global profiles defined*

