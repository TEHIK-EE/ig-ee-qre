# ee.fhir.qre#1.0.0: Küsimustike teenus

## Pages

* [Sissejuhatus](index.md)
* [Artifacts Summary](artifacts.md)
* [Allalaadimised](download.md)

## Resources

### CodeSystems

* [Sagedus ajas](CodeSystem-sagedus-ajas.md)

### ValueSets

* [Kõigist ravisekkumistest keeldumise ulatus](ValueSet-pet-all-intervention-refusal-vs.md)
* [Elu säilitavast sekkumisest keeldumise ulatus](ValueSet-pet-all-or-some-refusal-of-treatment-vs.md)
* [PET tahteavalduse rakendumise valikud](ValueSet-pet-indication-vs.md)
* [Palliatiivravi ulatus](ValueSet-pet-palliative-care-fully-or-not-vs.md)
* [Sagedus ajas loend](ValueSet-sagedus-ajas.md)

### Resource Profiles

* [EEHealthDeclarationQuestionnaire](StructureDefinition-ee-health-declaration-questionnaire.md)
* [PETQuestionnaire](StructureDefinition-pet-questionnaire.md)

### ImplementationGuides

* [Küsimustike teenus](index.md)

### Questionnaires

* [Tervisedeklaratsioon](Questionnaire-Questionnaire-health-declaration.md)

### Examples

* [Patsiendi elulõpu tahteavaldus (Questionnaire)](Questionnaire-Questionnaire-PET.md)
* [Tervisedeklaratsioon CDA-st (Questionnaire)](Questionnaire-Questionnaire-health-declaration-cda.md)
* [Tervisedeklaratsioon (Questionnaire)](Questionnaire-Questionnaire-health-declaration.md)
